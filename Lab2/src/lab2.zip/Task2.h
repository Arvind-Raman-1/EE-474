//FILENAME Task2.h
//Authors: Arvind Raman, Aadithya Manoj
// 2/04/2025
//this file is the header file for task 2

#ifndef TASK2_H
#define TASK2_H

// Function prototypes for Task 2
void setupTask2();
void task2_digitalWrite();
void task2_directRegister();

#endif // TASK2_H
