//FILENAME Task1.h
//Authors: Arvind Raman, Aadithya Manoj
// 2/04/2025
//this file is the header file for task 1


#ifndef TASK1_H
#define TASK1_H

// Function prototypes for Task 1
void setupTask1();
void task1();

#endif // TASK1_H
